export default function HeroSection() {
  return (
    <section id="heroSection" className="hero--section">
      <div className="hero--section--content--box">
        <div className="hero--section--content">
          <p className="section--title">Assalomu alaykum! Men Ayapxomova Nigora</p>
          <h1 className="hero--section--title">
            <span className="hero--section-title--color">Full Stack</span>{" "}
            <br />
            Dasturchiman
          </h1>
          <p className="hero--section-description">
            Mening veb dasturlash soxasida bir qancha loyixalar 
            <br /> bilan ishlaganman. Shu bilan birga dasturlash yo`nalishlarda ham ishladim.
          </p>
        </div>
      </div>
      <div className="hero--section--img">
        <img src="./img/H1.jpg" alt="H1" />
      </div>
    </section>
  );
}
